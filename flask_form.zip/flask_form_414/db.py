import sqlite3

db_user=sqlite3.connect('user.db')
cursor_db=db_user.cursor()

sql_create='''
 create table Users
(
Id integer primary key autoincrement,
FirstName text not null,
LastName text not null,
Email text not null unique,
Telephone text not null,
Password text not null
); 
 '''

sql_insert='''INSERT INTO Users(FirstName,LastName,Email,Telephone,Password) 
VALUES('Вася','Пупкин','vp@mail.ru','+70000000000','12345');'''

cursor_db.execute(sql_create)
db_user.commit()
cursor_db.execute(sql_insert)
db_user.commit()
cursor_db.close()
db_user.close()