from flask import Flask,request, render_template,redirect,url_for
import sqlite3

app=Flask(__name__)
import os
SECRET_KEY=os.urandom(32)
app.config['SECRET_KEY']=SECRET_KEY

@app.route('/',methods=['GET'])
def index():
    db_user=sqlite3.connect('user.db')
    cursor_db = db_user.cursor()
    cursor_db.execute('''SELECT FirstName||' '||LastName as FullName FROM Users; ''')
    data=cursor_db.fetchall()
    return render_template('index.html',title="Главная",info_table=data)


@app.route('/main')
def main():
    return redirect(url_for('index'))

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        Email = request.form.get('Email')
        Password = request.form.get('Password')
        db_user = sqlite3.connect('user.db')
        cursor_db = db_user.cursor()
        cursor_db.execute(('''SELECT Password From Users where Email='{}';''').format(Email))

        pas=cursor_db.fetchall()
        cursor_db.close
        try:
            if pas[0][0]!=Password:
                return render_template('bad_login.html')
        except:
            return render_template('bad_login.html')
        db_user.close()
        return render_template('success_login.html')
    return render_template('login.html',title="Авторизация")

@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        FirstName = request.form.get('FirstName')
        LastName = request.form.get('LastName')
        Email = request.form.get('Email')
        Telephone = request.form.get('Telephone')
        Password = request.form.get('Password')
        selected_options = request.form.getlist('checkbox')

        db_user = sqlite3.connect('user.db')
        cursor_db = db_user.cursor()
        if ", ".join(selected_options)!='on':
            return render_template('checkbox.html')
        else:
            sql_insert='''INSERT INTO Users(FirstName,LastName,Email,Telephone,Password) 
            VALUES('{}','{}','{}','{}','{}');'''.format(FirstName,LastName,Email,Telephone,Password)
            cursor_db.execute(sql_insert)
            db_user.commit()
            cursor_db.close()
            db_user.close()
            return render_template('success_register.html')

    return render_template('register.html',title="Регистрация")

if __name__=='__main__':
    app.run()